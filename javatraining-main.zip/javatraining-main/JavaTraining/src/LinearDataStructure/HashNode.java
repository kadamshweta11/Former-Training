package LinearDataStructure;



class HashNode {
	Integer key;
	String value;
	public HashNode next;
	
	
	public HashNode(Integer key,String value) {
		this.key=key;
		this.value=value;
		
	}
}
