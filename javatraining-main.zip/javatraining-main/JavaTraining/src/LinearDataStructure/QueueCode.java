package LinearDataStructure;

import java.util.Scanner;

public class QueueCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		MyQueue m=new MyQueue(6);
		int q=1;
		System.out.println("Queue Working");
		while(q!=0) {
			
			System.out.println("1.Push  2. Pop   3.display   4.Reverse   5.Size   6.Peek    7.Contains/Search   8.Center   9.Sort   10.Iterate");
			int op=sc.nextInt();
			switch(op) {
			case 1:
				int ele=sc.nextInt();
				m.Enqueue(ele);
				break;
			case 2:
				int showele;
				showele=m.Dequeue();
				System.out.println("Popped element is=");
				System.out.println(showele+" ");
				break;
			case 3:
				System.out.println("Elements in queue are=");
				m.display();
				break;
			case 4:
				
				m.reverse();
				break;
			case 5:
				System.out.println("Size of queue="+ m.size());
//				1m.size();
				break;
			case 6:
				System.out.println("Peek element is=");
				System.out.println(m.peek());
				break;
			case 7:
//				System.out.println("Search no is already 30");
				System.out.println("Enter element to search=");
				int n=sc.nextInt();
				m.search(n);
				break;
			case 8:
				m.Middle();
				break;
			case 9:
				System.out.println("Sorted elemets are=");
				m.sort();
				break;
			case 10:
				m.iterate();
				break;
//			case 5:
//				q=0;
			}
		
//	System.out.println(m.Enqueue(500));
//	System.out.println(m.Enqueue(300));
//	System.out.println(m.Enqueue(400));
//	System.out.print(m.Enqueue(5000));
//	System.out.println("Size"+m.size());
//	System.out.println("Peek Element"+m.peek());
//	System.out.println("detele from list"+m.Dequeue());
//	m.reverse();
//	m.search();
//	m.Middle();
//
//		System.out.println("Sorted elemets are=");
//		m.sort();
		
//		iterator
//		Iterator<Integer> itr=m.iterator();
//		while(itr.hasNext()) {
//			Object o=itr.next();
//				System.out.println(o);
//		}
//		
//		
//		
//		
//		
//	}
//	public int index;
//	private Iterator iterator() {
//		
//		index=0;
//		return ;
//		
//		
//	}
//	public boolean hasNext() {
//		return index < arr.length;
//	}
	}
	}
}

