/**
 * 
 */
/**
 * @author shwetakadam
 *
 */
module CoreJavaTraining {
}