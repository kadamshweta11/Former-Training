
var selectedrow=null;

function onInfoSubmit(){
event.preventDefault();
var formdata=readformdata();

if(selectedrow==null){
    InsertNew(formdata);
   
}
// displayRadioValue();
// getValue()
resetform();

}




function readformdata(){
    var formdata={};
    formdata['Name']=document.getElementById("Name").value;
    formdata['Email']=document.getElementById("Email").value;
    // formdata['website']=document.getElementById("website").value;
    formdata['website']=document.getElementById('website').value,
            a=document.createElement('a');
            a.href=formdata['website'];
    // formdata['imagename']=document.getElementById("imagename").value;
    // var val = document.getElementById('imagename').value,
    //     // src = 'http://webpage.com/images/' + val +'.png',
    //     img = document.createElement('img');

    // img.src = val;
    // document.body.appendChild(img);
     formdata['gender']=document.querySelector('input[name="gender"]:checked').value;
    formdata['checks'] =  document.getElementsByName('checks'); 
         var result = ""; 
            for (var i = 0; i < 3; i++) { 
                if (formdata['checks'][i].checked) { 
                    result += formdata['checks'][i].value+",";

                } 
                console.log(result);
            } 
            formdata['checks']=result;
        //  console.log(result);
    return formdata;
}
 // insert data
function InsertNew(data){
    var table=document.getElementById("InfoList").getElementsByTagName('tbody')[0];
    var newRow=table.insertRow(table.length);
    
    var cel1=newRow.insertCell(0);
    var val=document.getElementById('website').value,
            a=document.createElement('a');
            a.href=val;
    cel1.innerHTML = `<div> <p>${data.Name}</p>
    <p>${data.gender}</p>
    <p>${data.Email}</p>
    <a href="">${data.website}</a>  
    <p>${data.checks}</p></div>`;
    var cel2=newRow.insertCell(-1);
    var val = document.getElementById('imagename').value,
    img = document.createElement('img');
    img.src = val;
    cel2.appendChild(img)=data.imagename;
}

function resetform(){
    document.getElementById('Name').value='';
    document.getElementById('Email').value='';
    document.getElementById('website').value='';
    document.getElementById('imagename').value='';
    //  document.getElementById('result').value='';
    // document.getElementById('Skills1').value='';
    
}





// image method 2
// document.getElementById('btn').onclick = function() {
//     var val = document.getElementById('imagename').value,
//         // src = 'http://webpage.com/images/' + val +'.png',
//         img = document.createElement('img');

//     img.src = val;
//     document.body.appendChild(img);

// }
