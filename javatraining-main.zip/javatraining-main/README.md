This Project Includes all the assignments given during training tenure.
