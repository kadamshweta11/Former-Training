
package LinearDataStructure;
import java.util.*;
public class MyQueue {
	static int arr[];
	static int size;
	static int front;
	 static int rear=-1;
	 
	 
		
		
//		constructor
		public MyQueue(int n){
			
			arr=new int[n];
			rear=-1;
			front=-1;
			size=0;
			
		}
		
	//isempty
		public static boolean isEmpty() {
			boolean valid=false;
			if(front==-1) {
				valid=true;
				
			}
			return valid;
		}
//		Enqueue
		public static int Enqueue(int ele) {

			if(rear==arr.length-1) {
				System.out.println("overflow");
			}else {
				
				if(front==-1 && rear==-1) {
					front=0;
					rear=0;
					arr[rear]=ele;
				}else {
					rear=rear+1;
					arr[rear]=ele;
				size++;
//					
				}
			}
			return ele;
		}
		
	//dequeue
		public static int Dequeue() {
			int valid=0;
//			if(size!=0) {
//				front++;
//				valid=arr[front];
//				size--;
//			}
//			return valid;
			if(front==-1 && rear==-1) {
				System.out.println("Underflow");
			}else {
//				front++;
				valid=arr[front++];
				size--;
			}
			return valid;
		}
		
//		peek
		public int peek() {
			return arr[front];
		}
//		size
		public int size() {
//			int len=arr.length;
//			return arr[len];
//			return len;
			return size+1;
			
		}
//		Reverse
		public void reverse() {
			System.out.println("Reversed queue is=");
			for(int i=rear;i>=front;i--) {
				System.out.println(arr[i]);
			}
		}
		
//		Search
		public void search(int key) {
			
			int index = 0;
			
			for(int i=0;i<size;i++) {
				if(arr[i]!=key) {
					index=index+1;
				
				}
			}
			if(index==0) {
				System.out.println("Element not found");
			}else {
				
				System.out.println("Element found at position="+index);
			}
			
		}
//		Print
		public void display() {
			
//				for(int i=0;i<arr.length;i++) {
//					System.out.println(arr[i]);
//				}
//			if(rear==-1) {
//				System.out.println("queue empty");
//				
//			}else {
				for(int i=front;i<=rear;i++) {
					System.out.println(arr[i]+" ");
				}
//				
//			}
			
		}
		
	///Center
		public void Middle() {
			int length=rear-1;
			System.out.println("Middle element is="+ arr[size/2]);
		}
		
	//Sort
		public void sort() {
			int temp;
			for(int i=0;i<arr.length;i++) {
				for(int j=i;j<arr.length;j++) {
					if(arr[i]>arr[j]) {
						temp=arr[i];
						arr[i]=arr[j];
						arr[j]=temp;
					}
				}
			}
			for(int a:arr) {
				System.out.println(a);
			}
		}
		
//		Iterator
		public void iterate() {
			
			for(int i=0;i<arr.length;i++) {
				System.out.println(arr[i]);
			}

			
			
		}
		

		
		
		
		
	}
